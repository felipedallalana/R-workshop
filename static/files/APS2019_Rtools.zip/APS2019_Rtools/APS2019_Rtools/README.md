# APS2019
Notes and files for the APS 2019 workshop on modeling techniques in R
The files include Rscripts, R markdown files, data examples, workshop slides, and outputs in PDF format from the R markdown files.
